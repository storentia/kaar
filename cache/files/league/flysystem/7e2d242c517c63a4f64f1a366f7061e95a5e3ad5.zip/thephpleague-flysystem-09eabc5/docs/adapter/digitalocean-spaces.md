---
layout: default
permalink: /adapter/digitalocean-spaces/
title: DigitalOcean Spaces
---

# DigitalOcean Spaces - S3 Compliant storage

The DO Spaces api are compatible with those of S3, from Flysystem's perspective this means you can use the
`league/flysystem-aws-s3-v3` adapter.
