<?php

namespace Tests\FakeProgram;

use Exception;

class FakeException extends Exception
{
}
