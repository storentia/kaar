<?php
use PHPUnit\Framework\TestCase;

class ThrowNoExceptionTestCase extends TestCase
{
    public function test()
    {
    }
}
